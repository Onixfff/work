﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Aeroblock
{
    public partial class General : Form
    {
        MySqlConnection mCon;
        //string conn = "Database=u0550310_aeroblock2; Server=31.31.196.61; port=3306; username=u0550_guseva; password=irinka20112004; charset=utf8 ";
     //string conn = "Database=aeroblock_2; Server=192.168.100.21; port=3306; username=sss_aebl; password=12345; charset=utf8 ";
        string conn = "Database=aeroblock_2; Server=localhost; port=3306; username=root; password=20112004; charset=utf8 ";
        string conn2 = "Database=u0550310_aeroblock; Server=31.31.196.61; port=3306; username=u0550_kornev; password=18061981Kornev; charset=utf8  ";
        string conn3 = "Database=order_aeroblock; Server=localhost; port=3306; username=root; password=20112004; charset=utf8 ";
        public General()
        {
            mCon = new MySqlConnection(conn);
            InitializeComponent();
        }

        private void General_Load(object sender, EventArgs e)
        {

        }

        private void возвратныеПаллетыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                IEnumerable<Pallet> list = null;
                list = MdiChildren.OfType<Pallet>();
                if (list != null && list.Count() > 0)
                {
                    list.First().Activate();
                }
                else
                {
                    Pallet form = new Pallet(conn);
                    form.MdiParent = this;
                    form.Show();
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show("Ошибка просмотра заявок", ex.Message);
                //Logger.Message("Ошибка просмотра заявок", ex.Message);
                //toolSSLState.Text = ex.Message;
            }

        }

        private void главнаяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                IEnumerable<RZD_general> list = null;
                list = MdiChildren.OfType<RZD_general>();
                if (list != null && list.Count() > 0)
                {
                    list.First().Activate();
                }
                else
                {
                    RZD_general form = new RZD_general(conn2);
                    form.MdiParent = this;
                    form.Show();
                }
            }


            catch (Exception ex)
            {
                //Logger.Message("Ошибка просмотра заявок", ex.Message);
                //toolSSLState.Text = ex.Message;
            }

        }

        private void отчетСводныйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                IEnumerable<report.General> list = null;
                list = MdiChildren.OfType<report.General>();
                if (list != null && list.Count() > 0)
                {
                    list.First().Activate();
                }
                else
                {
                    report.General form = new report.General();
                    form.MdiParent = this;
                    form.Show();
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show("Ошибка просмотра заявок", ex.Message);
                //Logger.Message("Ошибка просмотра заявок", ex.Message);
                //toolSSLState.Text = ex.Message;
            }

        }

        private void входToolStripMenuItem_Click(object sender, EventArgs e)
        {

            user_pass up = new user_pass(conn);

            if (up.ShowDialog() == DialogResult.OK)
            {
                входНеВыполненToolStripMenuItem.Text = "" + up.user + "";
                входToolStripMenuItem.Enabled = false;
            }
            if (up.previl == "1")
            {
                toolStripMenuItem1.Enabled = true;
                //остаткиПоСчетамToolStripMenuItem.Enabled = true;
                //реестрСчетовToolStripMenuItem.Enabled = true;
                //справочникиToolStripMenuItem.Enabled = true;
                //окнаToolStripMenuItem.Enabled = true;

            }
            if (up.previl == "2")
            {
                //заявкиToolStripMenuItem.Enabled = true;
                //остаткиПоСчетамToolStripMenuItem.Enabled = true;
                //реестрСчетовToolStripMenuItem.Enabled = true;
                //справочникиToolStripMenuItem.Enabled = true;
                //работникиГКToolStripMenuItem.Visible = false;

                //окнаToolStripMenuItem.Enabled = true;

            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
            входToolStripMenuItem.Enabled = true;
            входНеВыполненToolStripMenuItem.Text = "Вход не выполнен";
            //заявкиToolStripMenuItem.Enabled = false;
            //остаткиПоСчетамToolStripMenuItem.Enabled = false;
            //реестрСчетовToolStripMenuItem.Enabled = false;
            //справочникиToolStripMenuItem.Enabled = false;
            //окнаToolStripMenuItem.Enabled = false;
        }

        private void ремонтПаллетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                IEnumerable<Remont_pal> list = null;
                list = MdiChildren.OfType<Remont_pal>();
                if (list != null && list.Count() > 0)
                {
                    list.First().Activate();
                }
                else
                {
                    Remont_pal form = new Remont_pal(conn);
                    form.MdiParent = this;
                    form.Show();
                }
            }


            catch (Exception ex)
            {
                //Logger.Message("Ошибка просмотра заявок", ex.Message);
                //toolSSLState.Text = ex.Message;
            }
        }

        private void каскадомToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void слеваНаправоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void сверхуВнизToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void закрытьВсеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void списокToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                IEnumerable<Order_GB> list = null;
                list = MdiChildren.OfType<Order_GB>();
                if (list != null && list.Count() > 0)
                {
                    list.First().Activate();
                }
                else
                {
                    Order_GB form = new Order_GB(conn3);
                    form.MdiParent = this;
                    form.Show();
                }
            }


            catch (Exception ex)
            {
                //Logger.Message("Ошибка просмотра заявок", ex.Message);
                //toolSSLState.Text = ex.Message;
            }
        }
    }
}
    

