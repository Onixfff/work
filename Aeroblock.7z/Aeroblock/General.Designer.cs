﻿namespace Aeroblock
{
    partial class General
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(General));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.входНеВыполненToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.входToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.газобетонныйЗаводToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сухиеСтроительныеСмесиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.силикатныйКирпичToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.бетонныйЗаводToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.тарифыИПотреблениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.электроэнергияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.водоснабжениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рЖДToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.главнаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.графикВыходаВагоновToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетПоНаходжениюВагоновToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетПоСкладамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.обнуленияСилосовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перемещенияТовараToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.газобетонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.главнаяToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетСводныйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.материалыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.номенклатураToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.группыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользователиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.группаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользовательToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.подразделениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оборудованиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.участокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.наименованиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.строительныеОбъектыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.складToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.возвратныеПаллетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ремонтПаллетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.окнаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.каскадомToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.слеваНаправоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сверхуВнизToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.закрытьВсеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(50, 50);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.входНеВыполненToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.справочникиToolStripMenuItem,
            this.отчетыToolStripMenuItem1,
            this.строительныеОбъектыToolStripMenuItem,
            this.складToolStripMenuItem,
            this.окнаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(150, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1259, 50);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // входНеВыполненToolStripMenuItem
            // 
            this.входНеВыполненToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.входToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.входНеВыполненToolStripMenuItem.Name = "входНеВыполненToolStripMenuItem";
            this.входНеВыполненToolStripMenuItem.Size = new System.Drawing.Size(119, 46);
            this.входНеВыполненToolStripMenuItem.Text = "Вход не выполнен";
            // 
            // входToolStripMenuItem
            // 
            this.входToolStripMenuItem.Name = "входToolStripMenuItem";
            this.входToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.входToolStripMenuItem.Text = "Вход";
            this.входToolStripMenuItem.Click += new System.EventHandler(this.входToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.газобетонныйЗаводToolStripMenuItem,
            this.сухиеСтроительныеСмесиToolStripMenuItem,
            this.силикатныйКирпичToolStripMenuItem,
            this.бетонныйЗаводToolStripMenuItem});
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(152, 46);
            this.toolStripMenuItem1.Text = "Заявки на производство";
            // 
            // газобетонныйЗаводToolStripMenuItem
            // 
            this.газобетонныйЗаводToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяToolStripMenuItem,
            this.списокToolStripMenuItem});
            this.газобетонныйЗаводToolStripMenuItem.Name = "газобетонныйЗаводToolStripMenuItem";
            this.газобетонныйЗаводToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.газобетонныйЗаводToolStripMenuItem.Text = "Газобетонный завод";
            // 
            // новаяToolStripMenuItem
            // 
            this.новаяToolStripMenuItem.Name = "новаяToolStripMenuItem";
            this.новаяToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.новаяToolStripMenuItem.Text = "Новая";
            // 
            // списокToolStripMenuItem
            // 
            this.списокToolStripMenuItem.Name = "списокToolStripMenuItem";
            this.списокToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.списокToolStripMenuItem.Text = "Список";
            this.списокToolStripMenuItem.Click += new System.EventHandler(this.списокToolStripMenuItem_Click);
            // 
            // сухиеСтроительныеСмесиToolStripMenuItem
            // 
            this.сухиеСтроительныеСмесиToolStripMenuItem.Name = "сухиеСтроительныеСмесиToolStripMenuItem";
            this.сухиеСтроительныеСмесиToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.сухиеСтроительныеСмесиToolStripMenuItem.Text = "Сухие строительные смеси";
            // 
            // силикатныйКирпичToolStripMenuItem
            // 
            this.силикатныйКирпичToolStripMenuItem.Name = "силикатныйКирпичToolStripMenuItem";
            this.силикатныйКирпичToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.силикатныйКирпичToolStripMenuItem.Text = "Силикатный кирпич";
            // 
            // бетонныйЗаводToolStripMenuItem
            // 
            this.бетонныйЗаводToolStripMenuItem.Name = "бетонныйЗаводToolStripMenuItem";
            this.бетонныйЗаводToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.бетонныйЗаводToolStripMenuItem.Text = "Бетонный завод";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.тарифыИПотреблениеToolStripMenuItem,
            this.электроэнергияToolStripMenuItem,
            this.водоснабжениеToolStripMenuItem,
            this.рЖДToolStripMenuItem});
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(64, 46);
            this.toolStripMenuItem2.Text = "Тарифы";
            // 
            // тарифыИПотреблениеToolStripMenuItem
            // 
            this.тарифыИПотреблениеToolStripMenuItem.Name = "тарифыИПотреблениеToolStripMenuItem";
            this.тарифыИПотреблениеToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.тарифыИПотреблениеToolStripMenuItem.Text = "Газ";
            // 
            // электроэнергияToolStripMenuItem
            // 
            this.электроэнергияToolStripMenuItem.Name = "электроэнергияToolStripMenuItem";
            this.электроэнергияToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.электроэнергияToolStripMenuItem.Text = "Электроэнергия";
            // 
            // водоснабжениеToolStripMenuItem
            // 
            this.водоснабжениеToolStripMenuItem.Name = "водоснабжениеToolStripMenuItem";
            this.водоснабжениеToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.водоснабжениеToolStripMenuItem.Text = "Водоснабжение";
            // 
            // рЖДToolStripMenuItem
            // 
            this.рЖДToolStripMenuItem.Name = "рЖДToolStripMenuItem";
            this.рЖДToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.рЖДToolStripMenuItem.Text = "РЖД";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.главнаяToolStripMenuItem,
            this.графикВыходаВагоновToolStripMenuItem,
            this.отчетыToolStripMenuItem});
            this.toolStripMenuItem3.Enabled = false;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(42, 46);
            this.toolStripMenuItem3.Text = "ПРУ";
            // 
            // главнаяToolStripMenuItem
            // 
            this.главнаяToolStripMenuItem.Name = "главнаяToolStripMenuItem";
            this.главнаяToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.главнаяToolStripMenuItem.Text = "Главная";
            this.главнаяToolStripMenuItem.Click += new System.EventHandler(this.главнаяToolStripMenuItem_Click);
            // 
            // графикВыходаВагоновToolStripMenuItem
            // 
            this.графикВыходаВагоновToolStripMenuItem.Name = "графикВыходаВагоновToolStripMenuItem";
            this.графикВыходаВагоновToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.графикВыходаВагоновToolStripMenuItem.Text = "График выхода вагонов";
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отчетПоНаходжениюВагоновToolStripMenuItem,
            this.отчетПоСкладамToolStripMenuItem,
            this.обнуленияСилосовToolStripMenuItem,
            this.перемещенияТовараToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // отчетПоНаходжениюВагоновToolStripMenuItem
            // 
            this.отчетПоНаходжениюВагоновToolStripMenuItem.Name = "отчетПоНаходжениюВагоновToolStripMenuItem";
            this.отчетПоНаходжениюВагоновToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.отчетПоНаходжениюВагоновToolStripMenuItem.Text = "Отчет по находжению вагонов";
            // 
            // отчетПоСкладамToolStripMenuItem
            // 
            this.отчетПоСкладамToolStripMenuItem.Name = "отчетПоСкладамToolStripMenuItem";
            this.отчетПоСкладамToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.отчетПоСкладамToolStripMenuItem.Text = "Отчет по складам";
            // 
            // обнуленияСилосовToolStripMenuItem
            // 
            this.обнуленияСилосовToolStripMenuItem.Name = "обнуленияСилосовToolStripMenuItem";
            this.обнуленияСилосовToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.обнуленияСилосовToolStripMenuItem.Text = "Обнуления силосов";
            // 
            // перемещенияТовараToolStripMenuItem
            // 
            this.перемещенияТовараToolStripMenuItem.Name = "перемещенияТовараToolStripMenuItem";
            this.перемещенияТовараToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.перемещенияТовараToolStripMenuItem.Text = "Перемещения товара";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.газобетонToolStripMenuItem});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(52, 46);
            this.toolStripMenuItem4.Text = "СУПП";
            // 
            // газобетонToolStripMenuItem
            // 
            this.газобетонToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.главнаяToolStripMenuItem1,
            this.отчетСводныйToolStripMenuItem});
            this.газобетонToolStripMenuItem.Name = "газобетонToolStripMenuItem";
            this.газобетонToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.газобетонToolStripMenuItem.Text = "Газобетон";
            // 
            // главнаяToolStripMenuItem1
            // 
            this.главнаяToolStripMenuItem1.Name = "главнаяToolStripMenuItem1";
            this.главнаяToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.главнаяToolStripMenuItem1.Text = "Главная";
            // 
            // отчетСводныйToolStripMenuItem
            // 
            this.отчетСводныйToolStripMenuItem.Name = "отчетСводныйToolStripMenuItem";
            this.отчетСводныйToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.отчетСводныйToolStripMenuItem.Text = "Отчет сводный";
            this.отчетСводныйToolStripMenuItem.Click += new System.EventHandler(this.отчетСводныйToolStripMenuItem_Click);
            // 
            // справочникиToolStripMenuItem
            // 
            this.справочникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.материалыToolStripMenuItem,
            this.номенклатураToolStripMenuItem,
            this.пользователиToolStripMenuItem,
            this.оборудованиеToolStripMenuItem});
            this.справочникиToolStripMenuItem.Enabled = false;
            this.справочникиToolStripMenuItem.Name = "справочникиToolStripMenuItem";
            this.справочникиToolStripMenuItem.Size = new System.Drawing.Size(94, 46);
            this.справочникиToolStripMenuItem.Text = "Справочники";
            // 
            // материалыToolStripMenuItem
            // 
            this.материалыToolStripMenuItem.Name = "материалыToolStripMenuItem";
            this.материалыToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.материалыToolStripMenuItem.Text = "Материалы";
            // 
            // номенклатураToolStripMenuItem
            // 
            this.номенклатураToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.группыToolStripMenuItem});
            this.номенклатураToolStripMenuItem.Name = "номенклатураToolStripMenuItem";
            this.номенклатураToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.номенклатураToolStripMenuItem.Text = "Номенклатура";
            // 
            // группыToolStripMenuItem
            // 
            this.группыToolStripMenuItem.Name = "группыToolStripMenuItem";
            this.группыToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.группыToolStripMenuItem.Text = "Группы";
            // 
            // пользователиToolStripMenuItem
            // 
            this.пользователиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.группаToolStripMenuItem,
            this.пользовательToolStripMenuItem,
            this.подразделениеToolStripMenuItem});
            this.пользователиToolStripMenuItem.Name = "пользователиToolStripMenuItem";
            this.пользователиToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.пользователиToolStripMenuItem.Text = "Пользователи";
            // 
            // группаToolStripMenuItem
            // 
            this.группаToolStripMenuItem.Name = "группаToolStripMenuItem";
            this.группаToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.группаToolStripMenuItem.Text = "Группа";
            // 
            // пользовательToolStripMenuItem
            // 
            this.пользовательToolStripMenuItem.Name = "пользовательToolStripMenuItem";
            this.пользовательToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.пользовательToolStripMenuItem.Text = "Пользователь";
            // 
            // подразделениеToolStripMenuItem
            // 
            this.подразделениеToolStripMenuItem.Name = "подразделениеToolStripMenuItem";
            this.подразделениеToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.подразделениеToolStripMenuItem.Text = "Подразделение";
            // 
            // оборудованиеToolStripMenuItem
            // 
            this.оборудованиеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.участокToolStripMenuItem,
            this.наименованиеToolStripMenuItem});
            this.оборудованиеToolStripMenuItem.Name = "оборудованиеToolStripMenuItem";
            this.оборудованиеToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оборудованиеToolStripMenuItem.Text = "Оборудование";
            // 
            // участокToolStripMenuItem
            // 
            this.участокToolStripMenuItem.Name = "участокToolStripMenuItem";
            this.участокToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.участокToolStripMenuItem.Text = "Участок";
            // 
            // наименованиеToolStripMenuItem
            // 
            this.наименованиеToolStripMenuItem.Name = "наименованиеToolStripMenuItem";
            this.наименованиеToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.наименованиеToolStripMenuItem.Text = "Наименование";
            // 
            // отчетыToolStripMenuItem1
            // 
            this.отчетыToolStripMenuItem1.Enabled = false;
            this.отчетыToolStripMenuItem1.Name = "отчетыToolStripMenuItem1";
            this.отчетыToolStripMenuItem1.Size = new System.Drawing.Size(60, 46);
            this.отчетыToolStripMenuItem1.Text = "Отчеты";
            // 
            // строительныеОбъектыToolStripMenuItem
            // 
            this.строительныеОбъектыToolStripMenuItem.Enabled = false;
            this.строительныеОбъектыToolStripMenuItem.Name = "строительныеОбъектыToolStripMenuItem";
            this.строительныеОбъектыToolStripMenuItem.Size = new System.Drawing.Size(149, 46);
            this.строительныеОбъектыToolStripMenuItem.Text = "Строительные объекты";
            // 
            // складToolStripMenuItem
            // 
            this.складToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.возвратныеПаллетыToolStripMenuItem});
            this.складToolStripMenuItem.Enabled = false;
            this.складToolStripMenuItem.Name = "складToolStripMenuItem";
            this.складToolStripMenuItem.Size = new System.Drawing.Size(52, 46);
            this.складToolStripMenuItem.Text = "Склад";
            // 
            // возвратныеПаллетыToolStripMenuItem
            // 
            this.возвратныеПаллетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ремонтПаллетToolStripMenuItem});
            this.возвратныеПаллетыToolStripMenuItem.Name = "возвратныеПаллетыToolStripMenuItem";
            this.возвратныеПаллетыToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.возвратныеПаллетыToolStripMenuItem.Text = "Возвратные паллеты";
            this.возвратныеПаллетыToolStripMenuItem.Click += new System.EventHandler(this.возвратныеПаллетыToolStripMenuItem_Click);
            // 
            // ремонтПаллетToolStripMenuItem
            // 
            this.ремонтПаллетToolStripMenuItem.Name = "ремонтПаллетToolStripMenuItem";
            this.ремонтПаллетToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.ремонтПаллетToolStripMenuItem.Text = "Ремонт паллет";
            this.ремонтПаллетToolStripMenuItem.Click += new System.EventHandler(this.ремонтПаллетToolStripMenuItem_Click);
            // 
            // окнаToolStripMenuItem
            // 
            this.окнаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.каскадомToolStripMenuItem,
            this.слеваНаправоToolStripMenuItem,
            this.сверхуВнизToolStripMenuItem,
            this.закрытьВсеToolStripMenuItem});
            this.окнаToolStripMenuItem.Name = "окнаToolStripMenuItem";
            this.окнаToolStripMenuItem.Size = new System.Drawing.Size(47, 46);
            this.окнаToolStripMenuItem.Text = "Окна";
            // 
            // каскадомToolStripMenuItem
            // 
            this.каскадомToolStripMenuItem.Name = "каскадомToolStripMenuItem";
            this.каскадомToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.каскадомToolStripMenuItem.Text = "Каскадом";
            this.каскадомToolStripMenuItem.Click += new System.EventHandler(this.каскадомToolStripMenuItem_Click);
            // 
            // слеваНаправоToolStripMenuItem
            // 
            this.слеваНаправоToolStripMenuItem.Name = "слеваНаправоToolStripMenuItem";
            this.слеваНаправоToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.слеваНаправоToolStripMenuItem.Text = "Слева направо";
            this.слеваНаправоToolStripMenuItem.Click += new System.EventHandler(this.слеваНаправоToolStripMenuItem_Click);
            // 
            // сверхуВнизToolStripMenuItem
            // 
            this.сверхуВнизToolStripMenuItem.Name = "сверхуВнизToolStripMenuItem";
            this.сверхуВнизToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.сверхуВнизToolStripMenuItem.Text = "Сверху вниз";
            this.сверхуВнизToolStripMenuItem.Click += new System.EventHandler(this.сверхуВнизToolStripMenuItem_Click);
            // 
            // закрытьВсеToolStripMenuItem
            // 
            this.закрытьВсеToolStripMenuItem.Name = "закрытьВсеToolStripMenuItem";
            this.закрытьВсеToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.закрытьВсеToolStripMenuItem.Text = "Закрыть все";
            this.закрытьВсеToolStripMenuItem.Click += new System.EventHandler(this.закрытьВсеToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // General
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 669);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "General";
            this.Text = "Система управления предприятиями Aeroblock";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.General_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem входНеВыполненToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem входToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem газобетонныйЗаводToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сухиеСтроительныеСмесиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem силикатныйКирпичToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem бетонныйЗаводToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem тарифыИПотреблениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem электроэнергияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem водоснабжениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem главнаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem графикВыходаВагоновToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетПоНаходжениюВагоновToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетПоСкладамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem обнуленияСилосовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem перемещенияТовараToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem справочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem материалыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem номенклатураToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem группыToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem газобетонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem главнаяToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem пользователиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem группаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пользовательToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem подразделениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рЖДToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетСводныйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оборудованиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem участокToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem наименованиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem строительныеОбъектыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem складToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem возвратныеПаллетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ремонтПаллетToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem окнаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem каскадомToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem слеваНаправоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сверхуВнизToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem закрытьВсеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списокToolStripMenuItem;
    }
}

