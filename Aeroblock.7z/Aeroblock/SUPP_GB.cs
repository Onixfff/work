﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Aeroblock
{
    public partial class SUPP_GB : Form
    {
        public SUPP_GB()
        {
            InitializeComponent();
        }

        private void SUPP_GB_Load(object sender, EventArgs e)
        {

        }
    }
}
